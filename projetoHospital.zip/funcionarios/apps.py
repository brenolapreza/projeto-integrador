from django.apps import AppConfig


class FuncionariosConfig(AppConfig):
    name = 'funcionarios'
