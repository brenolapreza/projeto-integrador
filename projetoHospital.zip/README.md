
# PROJETO INTEGRADOR #

## Models - Breno e Gustavo ##
	- O que é
	- Onde está aplicado no nosso pi

## Herança - Hugo ##
	- O que é
	- Onde está aplicado no nosso pi

## Encapsulamento - Rafael ##
	- O que é
	- Onde está aplicado no nosso pi

## Polimorfismo - Luiz ##
	- O que é
	- Onde está aplicado no nosso pi




