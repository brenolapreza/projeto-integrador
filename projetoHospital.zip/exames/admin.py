from django.contrib import admin
from .models import Exame
admin.site.register(Exame)
# Register your models here.