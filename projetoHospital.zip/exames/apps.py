from django.apps import AppConfig


class ExamesConfig(AppConfig):
    name = 'exames'
