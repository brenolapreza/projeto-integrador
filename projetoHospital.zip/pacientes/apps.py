from django.apps import AppConfig


class PacientesConfig(AppConfig):
    name = 'pacientes'
