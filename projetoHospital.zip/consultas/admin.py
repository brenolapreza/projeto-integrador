from django.contrib import admin
from .models import Consulta
admin.site.register(Consulta)