from django.apps import AppConfig


class ConsultasConfig(AppConfig):
    name = 'consultas'
